import json
import jwt
import boto3
import os
import logging
from datetime import datetime, timedelta
import urllib.request
import urllib.error
import urllib.parse

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

dynamodb = boto3.resource('dynamodb')


def lambda_handler(event, context):
    try:
        logger.info(f"Received event: {json.dumps(event)}")

        # Will receive body payload like this in JSON - have to convert that to a form encoded body
        # {
        #     "grant_type": "client_credentials",
        #     "client_id": "224c4h151012ftl8nfsbbhk5rg",
        #     "client_secret": "1k2uuqqva9ujs5ol2at7u2gi4ov8p19vs3r4ei8qf3bd4rabidrj",
        #     "audience": "https://test.api.ats.healthcare"
        # }

        body_str = event.get("body", None)
        if body_str is None:
            return error_response(status_code=400, message="Missing body")

        body = json.loads(body_str)
        client_id = body['client_id']
        client_secret = body['client_secret']
        audience = body['audience']

        cache_key = client_id

        # Check cache first
        cached_token = get_cached_token(client_id)
        if cached_token:
            logger.info(f"Token found in cache for client_id: {client_id}")
            return success_response(cached_token)
        else:
            logger.info(f"Token NOT found in cache for client_id: {client_id}")


        # Get new token using client credentials grant
        token_response = get_cognito_token_client_credentials(client_id=client_id, client_secret=client_secret, audience=audience)
        if not token_response:
            return error_response(500, 'Failed to obtain token from Cognito')

        # Store in cache
        store_token_cache(cache_key, token_response['access_token'], client_id)
        logger.info(f"New token obtained and cached for client_id: {client_id}")

        return success_response(token_response)

    except Exception as e:
        logger.error(f"Error processing request: {str(e)}")
        return error_response(500, 'Internal server error')


def get_cached_token(cache_key):
    table = dynamodb.Table(os.environ['TOKEN_CACHE_TABLE'])
    try:
        response = table.get_item(Key={'cache_key': cache_key})
        if 'Item' in response:
            # Check if token is still valid (not expired)
            ttl = response['Item'].get('ttl', 0)
            if ttl > int(datetime.now().timestamp()):
                return response['Item']['token']
            else:
                logger.info(f"Cached token expired for key: {cache_key}")
    except Exception as e:
        logger.error(f"Error retrieving cached token: {str(e)}")
    return None


# def get_partner_config(partner_id):
#     table = dynamodb.Table(os.environ['PARTNER_CONFIG_TABLE'])
#     try:
#         response = table.get_item(Key={'partner_id': partner_id})
#         return response.get('Item')
#     except Exception as e:
#         logger.error(f"Error retrieving partner config: {str(e)}")
#         return None


def get_cognito_token_client_credentials(client_id: str, client_secret: str, audience: str):
    try:
        # This should be a configuration - including the entire URL to avoid the region hardcode problem below.
        domain = "m2m-token-202511241354"

        token_url = f"https://{domain}.auth.ca-central-1.amazoncognito.com/oauth2/token"

        # Prepare request data - include the scope that maps to the audience and request to issue a token
        data = f"grant_type=client_credentials&scope={audience}/issue"

        # Create Basic Auth header
        import base64
        credentials = f"{client_id}:{client_secret}"
        encoded_credentials = base64.b64encode(credentials.encode()).decode()

        # Make the OAuth request
        req = urllib.request.Request(
            token_url,
            data=data.encode(),
            headers={
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': f'Basic {encoded_credentials}'
            }
        )

        with urllib.request.urlopen(req) as response:
            response_data = json.loads(response.read().decode())
            print(response_data)
            access_token = response_data.get('access_token')

            if access_token:
                logger.info("Successfully obtained access token from Cognito")
                return response_data
            else:
                logger.error("No access token in Cognito response")
                return None

    except urllib.error.HTTPError as e:
        logger.error(f"HTTP error obtaining Cognito token: {e.code} - {e.read().decode()}")
        return None
    except Exception as e:
        logger.error(f"Error obtaining Cognito token: {str(e)}")
        return None


def store_token_cache(cache_key, token, client_id):
    table = dynamodb.Table(os.environ['TOKEN_CACHE_TABLE'])

    decoded_token = jwt.decode(token, options={"verify_signature": False})
    exp = decoded_token.get('exp')

    # Set TTL to 50 minutes (token expires in 1 hour)
    # Set TTL to be 90% of the time between now and the expiry time of the token (currently 1 day, but should be dynamic)
    ttl = int((datetime.now() + timedelta(hours=23)).timestamp())

    # The cache should include audience as a second key to avoid potential cross audience usage

    try:
        table.put_item(
            Item={
                'cache_key': cache_key,
                'token': token,
                'exp': exp,
                'ttl': ttl,
                'created_at': datetime.now().isoformat()
            }
        )
        logger.info(f"Token cached successfully for partner: {client_id}")
    except Exception as e:
        logger.error(f"Error storing token in cache: {str(e)}")


def success_response(token):
    return {
        'statusCode': 200,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps(token)
    }


def error_response(status_code, message):
    return {
        'statusCode': status_code,
        'headers': {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*'
        },
        'body': json.dumps({
            'error': message,
            'timestamp': datetime.now().isoformat()
        })
    }